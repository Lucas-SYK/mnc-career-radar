import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from update_jobs import is_target_job, is_valid_url, iter_jobposting, fetch_greenhouse, fetch_lever


class FakeResponse:
    def __init__(self, value): self.value = value
    def raise_for_status(self): return None
    def json(self): return self.value


class FakeSession:
    def __init__(self, value): self.value = value
    def get(self, url, timeout): return FakeResponse(self.value)


class UpdateTests(unittest.TestCase):
    def test_offshore_rejected(self):
        self.assertFalse(is_target_job("Graduate Automation Engineer", "early career engineering", "Paris, France"))

    def test_campus_engineer_accepted(self):
        self.assertTrue(is_target_job("2027 Graduate Automation Engineer", "entry level", "Shanghai, China"))

    def test_unsafe_url_rejected(self):
        self.assertFalse(is_valid_url("javascript:alert(1)"))
        self.assertTrue(is_valid_url("https://careers.example.com/job?id=1"))

    def test_jsonld_graph(self):
        payload = {"@graph": [{"@type": "Organization"}, {"@type": "JobPosting", "title": "Engineer"}]}
        self.assertEqual(len(list(iter_jobposting(payload))), 1)

    def test_greenhouse_filter(self):
        s = FakeSession({"jobs":[{"id":1,"title":"Graduate Controls Engineer","location":{"name":"Shanghai, China"},"content":"Entry level automation","absolute_url":"https://boards.greenhouse.io/test/1"},{"id":2,"title":"Senior Manager","location":{"name":"New York"},"absolute_url":"https://boards.greenhouse.io/test/2"}]})
        jobs=fetch_greenhouse(s, {"board_token":"valid","company_id":"bosch"})
        self.assertEqual(len(jobs), 1)

    def test_lever_filter(self):
        s=FakeSession([{"id":"id1","text":"校园招聘 自动化工程师","categories":{"location":"青岛, 中国"},"descriptionPlain":"应届毕业生","hostedUrl":"https://jobs.lever.co/org/id1"}])
        self.assertEqual(len(fetch_lever(s, {"site":"org","company_id":"siemens"})),1)


if __name__ == "__main__": unittest.main()
