"""Official-source job updater. Does not submit applications or store applicant data."""
from __future__ import annotations
import argparse
import hashlib
import json
import logging
import re
from datetime import datetime, timezone, timedelta, date
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]
CN = timezone(timedelta(hours=8))
LOG = logging.getLogger(__name__)
CHINA = ("china", "中国", "shanghai", "上海", "beijing", "北京", "shenzhen", "深圳", "suzhou", "苏州", "qingdao", "青岛", "jinan", "济南", "nanjing", "南京", "hangzhou", "杭州", "guangzhou", "广州", "wuxi", "无锡", "tianjin", "天津", "chengdu", "成都", "wuhan", "武汉", "xi'an", "西安", "xiamen", "厦门", "dalian", "大连", "ningbo", "宁波", "changzhou", "常州")
CAREER = ("graduate", "new grad", "campus", "entry level", "entry-level", "early career", "university", "intern", "应届", "校招", "毕业生", "管培", "培训生", "实习")
RELEVANT = ("control", "automation", "embedded", "robot", "computer vision", "software", "engineer", "algorithm", "electrical", "manufacturing", "plc", "scada", "autonomous", "机器视觉", "控制", "自动化", "嵌入式", "机器人", "软件", "算法", "电气", "工程", "智能制造", "研发")


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def is_valid_url(url: str) -> bool:
    parsed = urlparse(url)
    return parsed.scheme == "https" and bool(parsed.netloc) and not parsed.username and not parsed.password


def make_id(prefix: str, value: str) -> str:
    return f"{prefix}-{hashlib.sha256(value.encode()).hexdigest()[:12]}"


def is_target_job(title: str, description: str, location: str) -> bool:
    """Strict safety gate: CN + junior/campus + relevant technical occupation."""
    all_text = (title + " " + description).lower()
    return (any(t in location.lower() for t in CHINA)
            and any(t in all_text for t in CAREER)
            and any(t in all_text for t in RELEVANT))


def clean_html(value: str) -> str:
    from bs4 import BeautifulSoup
    return BeautifulSoup(value or "", "html.parser").get_text(" ", strip=True)[:1200]


def fetch_greenhouse(session: Any, entry: dict[str, Any]) -> list[dict[str, Any]]:
    token = entry["board_token"]
    if not re.fullmatch(r"[A-Za-z0-9_-]+", token):
        raise ValueError("Invalid Greenhouse board token")
    api = f"https://boards-api.greenhouse.io/v1/boards/{token}/jobs?content=true"
    response = session.get(api, timeout=20)
    response.raise_for_status()
    jobs = []
    for item in response.json().get("jobs", []):
        title = item.get("title", "")
        location = (item.get("location") or {}).get("name", "")
        body = clean_html(item.get("content", ""))
        url = item.get("absolute_url", "")
        if not (is_valid_url(url) and is_target_job(title, body, location)):
            continue
        jobs.append({"id": make_id("gh", str(item.get("id", url))), "company_id": entry["company_id"], "title": title,
                     "category": "校招/初级工程", "locations": [location], "cohort": "待官网确认", "employment": "校园/初级（自动识别，需核对）",
                     "description": body[:650], "requirements": "以官方岗位说明为准", "source_url": url, "apply_url": url,
                     "apply_type": "直接岗位页面", "source_type": "Greenhouse 官方公开职位接口", "keywords": ["自动识别"],
                     "last_manually_verified": None})
    return jobs


def fetch_lever(session: Any, entry: dict[str, Any]) -> list[dict[str, Any]]:
    site = entry["site"]
    if not re.fullmatch(r"[A-Za-z0-9_-]+", site):
        raise ValueError("Invalid Lever site")
    response = session.get(f"https://api.lever.co/v0/postings/{site}?mode=json", timeout=20)
    response.raise_for_status()
    jobs = []
    for item in response.json():
        title = item.get("text", "")
        cat = item.get("categories") or {}
        location = cat.get("location", "")
        body = clean_html(item.get("descriptionPlain") or item.get("description") or "")
        url = item.get("hostedUrl", "") or item.get("applyUrl", "")
        if not (is_valid_url(url) and is_target_job(title, body, location)):
            continue
        jobs.append({"id": make_id("lever", str(item.get("id", url))), "company_id": entry["company_id"], "title": title,
                     "category": "校招/初级工程", "locations": [location], "cohort": "待官网确认", "employment": "校园/初级（自动识别，需核对）",
                     "description": body[:650], "requirements": "以官方岗位说明为准", "source_url": url, "apply_url": url,
                     "apply_type": "直接岗位页面", "source_type": "Lever 官方公开职位接口", "keywords": ["自动识别"],
                     "last_manually_verified": None})
    return jobs


def iter_jobposting(obj: Any):
    if isinstance(obj, list):
        for sub in obj:
            yield from iter_jobposting(sub)
    elif isinstance(obj, dict):
        typ = obj.get("@type", [])
        types = typ if isinstance(typ, list) else [typ]
        if "JobPosting" in types:
            yield obj
        for key in ("@graph", "mainEntity", "itemListElement"):
            if key in obj:
                yield from iter_jobposting(obj[key])


def fetch_jsonld(session: Any, entry: dict[str, Any]) -> list[dict[str, Any]]:
    from bs4 import BeautifulSoup
    url = entry["url"]
    if not is_valid_url(url):
        raise ValueError("Invalid JSON-LD URL")
    response = session.get(url, timeout=20)
    response.raise_for_status()
    html = BeautifulSoup(response.text, "html.parser")
    jobs = []
    for script in html.select('script[type="application/ld+json"]'):
        try:
            payload = json.loads(script.string or script.get_text())
        except (json.JSONDecodeError, ValueError):
            continue
        for item in iter_jobposting(payload):
            title = item.get("title", "")
            desc = clean_html(item.get("description", ""))
            loc = item.get("jobLocation", [])
            loc_list = loc if isinstance(loc, list) else [loc]
            places = []
            for place in loc_list:
                if isinstance(place, dict):
                    address = place.get("address") or {}
                    if isinstance(address, dict):
                        places.append(" ".join(str(address.get(k, "")) for k in ("addressLocality", "addressRegion", "addressCountry")))
            location = ", ".join(places)
            apply_url = item.get("url") or url
            if not (is_valid_url(apply_url) and is_target_job(title, desc, location)):
                continue
            jobs.append({"id": make_id("jsonld", apply_url), "company_id": entry["company_id"], "title": title,
                         "category": "校招/初级工程", "locations": [location], "cohort": "待官网确认", "employment": "校园/初级（自动识别，需核对）",
                         "description": desc[:650], "requirements": "以官方岗位说明为准", "source_url": url, "apply_url": apply_url,
                         "apply_type": "直接岗位页面", "source_type": "官网 JobPosting 结构化数据", "keywords": ["自动识别"],
                         "last_manually_verified": None})
    return jobs


def run(offline: bool = False) -> dict[str, Any]:
    import requests
    now = datetime.now(CN)
    companies = load_json(ROOT / "config/companies.json")
    curated = load_json(ROOT / "config/jobs_curated.json")
    config = load_json(ROOT / "config/integrations.json")
    known_ids = {c["id"] for c in companies}
    for job in curated:
        if job["company_id"] not in known_ids or not is_valid_url(job["apply_url"]):
            raise ValueError(f"Invalid curated job: {job['id']}")
        last = job.get("last_manually_verified")
        age = (now.date() - date.fromisoformat(last)).days if last else None
        job["verification"] = "人工核实（请再次核对招聘状态）" if age is not None and age <= 14 else "核验已超过14天（以官网为准）"
    jobs = list(curated)
    checks = []
    errors = []
    with requests.Session() as session:
        session.headers.update({"User-Agent": "CampusRadar/1.0 (personal job discovery; respectful low-frequency checks)", "Accept": "application/json,text/html;q=0.9,*/*;q=0.5"})
        for company in companies:
            result = {"company_id": company["id"], "checked_at": now.isoformat(), "status": "未执行（离线演示）" if offline else "无法验证", "note": "官网页面可访问不代表当前有在招校招职位"}
            if not offline:
                try:
                    resp = session.get(company["url"], timeout=15, stream=True)
                    result["status"] = "可访问" if 200 <= resp.status_code < 400 else f"HTTP {resp.status_code}（待核查）"
                    resp.close()
                except requests.RequestException as e:
                    result["status"] = "访问失败（不代表招聘关闭）"
                    errors.append(f"{company['id']} check: {type(e).__name__}")
            checks.append(result)
        if not offline:
            for mode, func in (("greenhouse", fetch_greenhouse), ("lever", fetch_lever), ("jsonld_job_pages", fetch_jsonld)):
                for entry in config.get(mode, []):
                    if entry.get("company_id") not in known_ids:
                        errors.append(f"unknown company in {mode}")
                        continue
                    try:
                        jobs.extend(func(session, entry))
                    except (requests.RequestException, ValueError, TypeError, KeyError) as e:
                        errors.append(f"{mode}:{entry['company_id']} {type(e).__name__}")
    unique = {j["id"]: j for j in jobs}  # same unique id = same official posting
    payload = {"generated_at": now.isoformat(timespec="seconds"), "timezone": "Asia/Shanghai", "jobs": list(unique.values()),
               "curated_count": len(curated), "auto_count": len(unique) - len(curated), "sources_configured": sum(len(config.get(k, [])) for k in ("greenhouse", "lever", "jsonld_job_pages")),
               "notice": "更新表示程序已运行；未配置官方岗位接口的公司仅检查招聘入口可达性，不代表该企业所有岗位已被采集。"}
    base = ROOT / "docs/data"
    write_json(base / "jobs.json", payload)
    write_json(base / "companies.json", companies)
    write_json(base / "status.json", {"generated_at": now.isoformat(timespec="seconds"), "checks": checks, "errors": errors})
    LOG.info("Generated %s jobs from %s companies (%s configured APIs)", len(unique), len(companies), payload["sources_configured"])
    return payload


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--offline", action="store_true", help="generate demo data without external calls")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    run(offline=args.offline)
