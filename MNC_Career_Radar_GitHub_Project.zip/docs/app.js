/* Browser-only application tracker. No resume uploads, cookies or third-party scripts. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const safe = v => String(v ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const safeUrl = url => { try { const u = new URL(url); return u.protocol === 'https:' ? safe(u.href) : '#'; } catch { return '#'; } };
  const KEY = 'campus-radar-tracker-v1';
  const loadLocal = () => { try { const s = JSON.parse(localStorage.getItem(KEY)||'{}'); return s && typeof s === 'object' ? s : {}; } catch { return {}; } };
  let state = loadLocal(), jobs = [], companies = [], meta = {};
  const saveLocal = () => { try { localStorage.setItem(KEY, JSON.stringify(state)); } catch { /* unavailable */ } };
  const company = id => companies.find(c => c.id === id) || { name:'企业', en:'Company', country:'', focus:'' };
  const companyLogo = c => ({siemens:'S', schneider:'SE', bosch:'B', abb:'ABB', kuka:'K', rockwell:'R', emerson:'E', continental:'C'})[c.id] || c.en.slice(0,2);
  const when = iso => { try { return new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}).format(new Date(iso)); } catch { return '未知'; } };
  function score(job) {
    let n = 60; const s = [job.title,job.description,(job.keywords||[]).join(' ')].join(' ').toLowerCase();
    if (/自动化|控制|automation|control/.test(s)) n += 15;
    if (/算法|机器视觉|robot|机器人|智能制造|工业软件|数字化/.test(s)) n += 10;
    if ((job.locations||[]).some(p => /青岛|济南/.test(p))) n += 10;
    if (job.cohort === '2027') n += 3;
    return Math.min(98,n); // keyword relevance, not employer eligibility prediction
  }
  function switchTab(tab) {
    document.querySelectorAll('.nav-button').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
    document.querySelectorAll('[data-panel]').forEach(panel => panel.classList.toggle('hidden', panel.dataset.panel !== tab));
    if (tab === 'tracker') renderTracker();
    document.querySelector('.main-section:not(.hidden)')?.scrollIntoView({behavior:'smooth',block:'start'});
  }
  const jobFields = j => [j.title,company(j.company_id).name,company(j.company_id).en,j.category,j.description,j.requirements,(j.keywords||[]).join(' '),(j.locations||[]).join(' ')].join(' ').toLowerCase();
  function renderJobs() {
    const query = $('search').value.trim().toLowerCase(), city=$('city-filter').value, field=$('field-filter').value, cohort=$('cohort-filter').value;
    const valid = jobs.filter(j => {
      const s = jobFields(j);
      if (query && !s.includes(query)) return false;
      if (cohort && j.cohort !== cohort) return false;
      if (city === '其他') { if ((j.locations||[]).some(p=> /青岛|济南|上海|苏州|北京/.test(p))) return false; }
      else if (city && !(j.locations||[]).some(p=>p.includes(city))) return false;
      if (field && !({控制:/控制|自动化|plc|control|automation/i,视觉:/视觉|算法|机器人|robot|vision/i,软件:/软件|嵌入式|embedded|software/i,培训:/培训|管培|graduate|sales100/i})[field].test(s)) return false;
      return true;
    }).sort((a,b)=>score(b)-score(a));
    $('results-count').textContent = `找到 ${valid.length} 个已收录岗位`;
    $('jobs-list').innerHTML = valid.length ? valid.map(jobMarkup).join('') : '<div class="empty">目前没有符合筛选条件的已核实岗位。可以前往「外企名录」查看企业官方职位。</div>';
  }
  function jobMarkup(j) {
    const c = company(j.company_id), record = state[j.id]||{};
    const tags=[j.employment,j.cohort+'届',...(j.locations||[]).slice(0,3),j.category].filter(Boolean);
    const last=j.last_manually_verified?`人工核实：${safe(j.last_manually_verified)}`:'自动获取：请核对官网';
    return `<article class="job"><div class="job-top"><div class="logo">${safe(companyLogo(c))}</div><div class="job-main"><div class="job-name">${safe(j.title)}</div><div class="job-company">${safe(c.name)} · ${safe(c.en)} · ${safe(c.country)}</div></div><div class="score"><strong>${score(j)}</strong><small>关键词匹配分</small></div></div><div class="tags">${tags.map((t,i)=>`<span class="tag ${i===0?'good':''}">${safe(t)}</span>`).join('')}</div><p class="job-desc">${safe(j.description)}</p><div class="job-meta"><span><strong>岗位要求</strong> ${safe(j.requirements)}</span><span><strong>核验说明</strong> ${safe(j.verification||'自动获取，待人工核对')}</span><span><strong>投递入口</strong> ${safe(j.apply_type)}</span><span><strong>来源</strong> ${safe(j.source_type)} · ${last}</span></div><div class="job-actions"><a class="apply" target="_blank" rel="noopener noreferrer" href="${safeUrl(j.apply_url)}">前往官方投递 ↗</a><a target="_blank" rel="noopener noreferrer" href="${safeUrl(j.source_url)}">查看原始公告 ↗</a><span class="spacer"></span><button data-action="save" data-id="${safe(j.id)}" class="${record.saved?'selected':''}">${record.saved?'★ 已收藏':'☆ 收藏'}</button><button data-action="apply" data-id="${safe(j.id)}" class="${record.applied?'selected':''}">${record.applied?'✓ 已标记投递':'标记已投'}</button></div></article>`;
  }
  function renderCompanies(status) {
    $('company-count').textContent = `${companies.length} 家官方企业入口`;
    $('companies-grid').innerHTML = companies.map(c=>{
      const check=(status?.checks||[]).find(k=>k.company_id===c.id);
      return `<article class="company"><div class="company-head"><div class="logo">${safe(companyLogo(c))}</div><span class="origin">${safe(c.country)}</span></div><h3>${safe(c.name)}</h3><span class="en">${safe(c.en)} · ${safe(check?.status||'未检查')}</span><p>${safe(c.focus)}</p><a href="${safeUrl(c.careers_url||c.url)}" rel="noopener noreferrer" target="_blank">进入企业官方招聘网站 ↗</a></article>`;
    }).join('');
  }
  function recalc(){
    $('metric-jobs').textContent=jobs.length;$('hero-job-count').textContent=jobs.length;
    $('metric-companies').textContent=companies.length;$('hero-company-count').textContent=companies.length;
    $('hero-sources-count').textContent=meta.sources_configured||0;
    $('metric-saved').textContent=Object.values(state).filter(v=>v.saved).length;
    $('metric-applied').textContent=Object.values(state).filter(v=>v.applied).length;
  }
  function renderTracker() {
    const selected=jobs.filter(j=>state[j.id]?.saved || state[j.id]?.applied).sort((a,b)=>Boolean(state[b.id]?.applied)-Boolean(state[a.id]?.applied));
    $('tracker-list').innerHTML=selected.length ? selected.map(jobMarkup).join('') : '<div class="empty">还没有收藏或已投岗位。先在「岗位广场」收藏感兴趣的职位。</div>';
  }
  function exportTracker() {
    const rows=[['岗位','企业','投递链接','已收藏','已投递','标记时间'],...jobs.filter(j=>state[j.id]?.saved || state[j.id]?.applied).map(j=>[j.title,company(j.company_id).name,j.apply_url,Boolean(state[j.id]?.saved),Boolean(state[j.id]?.applied),state[j.id]?.updated||''])];
    const csv='\uFEFF'+rows.map(row=>row.map(x=>'"'+String(x).replaceAll('"','""')+'"').join(',')).join('\r\n');
    const blob=new Blob([csv],{type:'text/csv;charset=utf-8'}),link=document.createElement('a'),url=URL.createObjectURL(blob);
    link.href=url;link.download='我的外企校招投递记录.csv';document.body.appendChild(link);link.click();link.remove();URL.revokeObjectURL(url);
  }
  async function main(){
    document.querySelectorAll('.nav-button').forEach(btn=>btn.addEventListener('click',()=>switchTab(btn.dataset.tab)));
    $('view-jobs').addEventListener('click',()=>switchTab('jobs'));
    $('view-companies').addEventListener('click',()=>switchTab('companies'));
    $('export-tracker').addEventListener('click',exportTracker);
    ['search','city-filter','field-filter','cohort-filter'].forEach(id=>$(id).addEventListener('input',renderJobs));
    document.addEventListener('click',ev=>{
      const button=ev.target.closest('button[data-action]'); if(!button) return;
      const {id,action}=button.dataset;
      if(!jobs.some(j=>j.id===id)) return;
      const rec=state[id]||{}; rec[action==='save'?'saved':'applied']=!rec[action==='save'?'saved':'applied'];rec.updated=new Date().toISOString();state[id]=rec;saveLocal();recalc();renderJobs();if(!document.querySelector('#tracker-tab').classList.contains('hidden')) renderTracker();
    });
    try {
      const [j,c,s]=await Promise.all(['./data/jobs.json','./data/companies.json','./data/status.json'].map(url=>fetch(url,{cache:'no-store'}).then(r=>{if(!r.ok)throw Error('HTTP '+r.status);return r.json();})));
      jobs=Array.isArray(j.jobs)?j.jobs:[];meta=j;companies=Array.isArray(c)?c:[];
      $('updated').textContent=`最近更新：${when(j.generated_at)}（北京时间）｜自动岗位接口 ${meta.sources_configured||0} 个`;
      $('footer-date').textContent=`数据更新：${safe(j.generated_at?.slice(0,10)||'—')}`;
      recalc();renderJobs();renderCompanies(s);renderTracker();
    } catch(error) {
      $('updated').textContent='数据载入失败，请通过 GitHub Pages 或本地 HTTP 服务打开网站';
      $('jobs-list').innerHTML='<div class="empty">读取数据失败。请勿直接以 file:// 协议打开 HTML。可运行 python -m http.server 8000 -d docs</div>';
    }
  }
  document.addEventListener('DOMContentLoaded',main);
})();
